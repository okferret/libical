#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double libicalVersionNumber;
FOUNDATION_EXPORT const unsigned char libicalVersionString[];

#import "libical/ical.h"
